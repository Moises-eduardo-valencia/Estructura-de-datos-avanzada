usu={
    "Moisés":{
    "Nombre":"Moisés"

},
    "Mirza":{
    "Nombre":"Mirza"
},
    "Luis":{
    "Nombre":"Luis"
},
    "Jorge":{
    "Nombre":"Jorge"
}
}
li={
    "Sapiens: De animales a dioses":{
    "Nombre":"Sapiens: De animales a dioses",
    "Autor":"Yuval Noah Harari",
    "Año de publicación":"2011",
},
    "El Alquimista":{
    "Nombre":"El Alquimista",
    "Autor":"Paulo Coelho",
    "Año de publicación":"1998",
},
    "1984":{
    "Nombre":"1984",
    "Autor":"George Orwell",
    "Año de publicación":"1949",
},
    "Cien años de soledad":{
    "Nombre":"Cien años de soledad",
    "Autor":"Gabriel García Márquez",
    "Año de publicación":"1967",
}
}

u=input("Ingresa el nombre de usuario: ")
c=input("Ingresa la contraseña: ")

if u in usu:
     n=usu[u]
     print(f"Hola, {n['Nombre']}. Bienvenido a la Biblioteca pública de Lázaro Cárdenas")
     print("¿Qué deseas realizar?")
     while True:
        print("MENÚ DE OPCIONES:")
        print("1. Buscar libro")
        print("2. Donar libro")
        print("3. Salir")
        op=input("Selecciona una opción: ")

        if op=="1":
            l=input("Ingresa el nombre del libro que deseas buscar: ")
            if l in li:
             no=li[l]
             print(f"Nombre: {no['Nombre']}")
             print(f"Autor: {no['Autor']}")
             print(f"Año de publicación: {no['Año de publicación']}")
            else:
                print("No existe el libro")
        if op=="2":
            nl={
             "Nombre":input("Ingrese la nombre del libro: "),
              "Autor":input("Ingrese el autor del libro: "),
             "Año de publicación":input("Ingrese el año de publicación: "),
             }
            print(f"Gracias por tu donación {n['Nombre']}")
        if op==3:
            print("3. Salir")
            print("Gracias por usar la Biblioteca. ¡Hasta luego!")
        break
            
else:    
    print("Usuario incorrecta, intenta de nuevo")