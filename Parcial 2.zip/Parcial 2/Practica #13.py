class Node:
    def __init__(self, data):
        self.data = data  # Dato del nodo
        self.next = None  # Puntero al siguiente nodo

class SinglyLinkedList:
    def __init__(self):
        self.head = None  # Inicialmente, la lista está vacía

    def insert_at_beginning(self, data):
        new_node = Node(data)
        new_node.next = self.head
        self.head = new_node

    def insert_at_end(self, data):
        new_node = Node(data)
        if not self.head:
            self.head = new_node
            return
        last_node = self.head
        while last_node.next:
            last_node = last_node.next
        last_node.next = new_node

    def delete_node(self, key):
        temp = self.head
        if temp and temp.data == key:
            self.head = temp.next
            temp = None
            return
        prev = None
        while temp and temp.data != key:
            prev = temp
            temp = temp.next
        if temp is None:
            return
        prev.next = temp.next
        temp = None

    def display(self):
        current = self.head
        while current:
            print(current.data, end=" -> ")
            current = current.next
        print("None")

# Ejemplo de uso
ll = SinglyLinkedList()
ll.insert_at_beginning(3)
ll.insert_at_end(5)
ll.insert_at_beginning(1)
ll.display()
