class Nodo:
    def_int_(self, valor):
        self.valor = valor
        self.siguiente = None
 #contrucción de la lista     
class ListaEnlazada:
    def_int_(self):
       self.cabeza = None
#pi
    def agregar(self,valor):
        self.nuevoNodo = Nodo(valor)
        if self.cabeza is None:
             self.cabeza = self.nuevoNodo
        else: