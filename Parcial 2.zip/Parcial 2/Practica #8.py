fila=[10, 20, 30, 40, 50, 60]
primer_elemento = fila[0]
print(f"Primer elemento: {primer_elemento}")
ultimo_elemento=fila[-1]
print(f"Último elemento: {ultimo_elemento}")
tamaño_fila=len(fila)
print(f"Tamaño de la fila: {tamaño_fila}")
print("Elementos de la fila:")
print(fila)
