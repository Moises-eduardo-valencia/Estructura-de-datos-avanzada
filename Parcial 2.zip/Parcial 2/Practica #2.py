a=[1,23,44,56,78,4,23,45,8,9,5,14,66]
v=int(input("Ingresa el valor que deseas buscar: "))
if v in a:
    print(v,"se encuentra en la lista")
else:
    print(v,"no se encuentra en la lista")